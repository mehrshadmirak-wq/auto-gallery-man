package com.sitracar.autogallery;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    final int navy=Color.rgb(13,25,40), teal=Color.rgb(0,190,190), pale=Color.rgb(235,242,248);
    DB db; LinearLayout root, body; String page="خانه"; Uri pickedPhoto=null;
    NumberFormat nf=NumberFormat.getInstance(new Locale("fa","IR"));
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); show();}
    String money(long n){return nf.format(n)+" ریال";}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(12,10,12,10);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal));b.setOnClickListener(v->r.run());return b;}
    void show(){
      root=column();root.setBackgroundColor(pale); setContentView(root);
      LinearLayout header=column();header.setBackgroundColor(navy); TextView title=text("🚘  اتو گالری من",25,Color.WHITE);title.setGravity(Gravity.CENTER);header.addView(title);TextView sub=text("مدیریت خودرو نمایشگاه سیترا",14,teal);sub.setGravity(Gravity.CENTER);header.addView(sub);root.addView(header);
      HorizontalScrollView hsv=new HorizontalScrollView(this);LinearLayout nav=row();for(String p:new String[]{"خانه","خودروها","مشتریان","بدهی‌ها"}){Button b=new Button(this);b.setText(p);b.setOnClickListener(v->{page=p;show();});nav.addView(b);}hsv.addView(nav);root.addView(hsv);
      ScrollView sc=new ScrollView(this);body=column();body.setPadding(12,10,12,20);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      if(page.equals("خانه")) dashboard(); else if(page.equals("خودروها")) cars(); else if(page.equals("مشتریان")) customers(); else debts();
    }
    void dashboard(){
      Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(buy),0) FROM cars WHERE sold=0",null);c.moveToFirst();int count=c.getInt(0);long value=c.getLong(1);c.close();
      Cursor s=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(sell-buy),0) FROM cars WHERE sold=1",null);s.moveToFirst();long profit=s.getLong(0);s.close();
      Cursor d=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM debts",null);d.moveToFirst();long debt=d.getLong(0);d.close();
      card("خودروهای موجود: "+nf.format(count)+" دستگاه\nارزش خرید موجودی: "+money(value)+"\nسود فروش ثبت‌شده: "+money(profit)+"\nجمع مانده حساب‌ها: "+money(debt));
      body.addView(button("+ ثبت خودروی جدید",()->carForm()));body.addView(button("+ ثبت مشتری",()->customerForm()));body.addView(button("+ ثبت بدهی یا طلب",()->debtForm()));
    }
    void card(String s){TextView t=text(s,17,Color.WHITE);t.setBackgroundTintList(null);t.setBackgroundColor(navy);t.setPadding(18,20,18,20);body.addView(t);}
    EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(navy);body.addView(e);return e;}
    void carForm(){page="خودروها";show();body.removeAllViews();body.addView(text("ثبت خودروی جدید",22,navy));EditText brand=edit("برند (مثلاً ایران‌خودرو)");EditText model=edit("مدل و تیپ");EditText year=edit("سال ساخت");EditText buy=edit("قیمت خرید به ریال");EditText sell=edit("قیمت فروش پیشنهادی به ریال");EditText note=edit("رنگ، کارکرد و توضیحات");body.addView(button("انتخاب عکس خودرو",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);}));body.addView(button("ذخیره خودرو",()->{if(brand.length()==0||model.length()==0||!number(buy)||!number(sell)){toast("برند، مدل و قیمت‌های معتبر را وارد کن.");return;}ContentValuesCompat.insertCar(db,brand.getText().toString(),model.getText().toString(),year.getText().toString(),Long.parseLong(buy.getText().toString()),Long.parseLong(sell.getText().toString()),note.getText().toString(),pickedPhoto==null?"":pickedPhoto.toString());pickedPhoto=null;toast("خودرو ثبت شد.");page="خودروها";show();}));}
    boolean number(EditText e){try{return e.length()>0&&Long.parseLong(e.getText().toString())>=0;}catch(Exception x){return false;}}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==11&&res==RESULT_OK&&data!=null){pickedPhoto=data.getData();try{getContentResolver().takePersistableUriPermission(pickedPhoto,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}toast("عکس انتخاب شد؛ پس از ثبت به خودرو متصل می‌شود.");}}
    void cars(){body.addView(button("+ افزودن خودرو",()->carForm()));Cursor c=db.getReadableDatabase().rawQuery("SELECT id,brand,model,year,buy,sell,note,sold FROM cars ORDER BY id DESC",null);if(c.getCount()==0)body.addView(text("هنوز خودرویی ثبت نشده است.",17,navy));while(c.moveToNext()){int id=c.getInt(0);String name=c.getString(1)+" "+c.getString(2);boolean sold=c.getInt(7)==1;LinearLayout box=column();box.setBackgroundColor(Color.WHITE);box.setPadding(8,6,8,6);box.addView(text(name+" · سال "+c.getString(3),19,navy));box.addView(text("خرید: "+money(c.getLong(4))+"\nفروش: "+money(c.getLong(5))+"\nوضعیت: "+(sold?"فروخته‌شده":"موجود")+(c.getString(6).isEmpty()?"":"\n"+c.getString(6)),14,navy));if(!sold){long sell=c.getLong(5);box.addView(button("ثبت فروش",()->new AlertDialog.Builder(this).setTitle("ثبت فروش").setMessage("فروش با قیمت پیشنهادی "+money(sell)+" ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("تأیید",(d,w)->{db.getWritableDatabase().execSQL("UPDATE cars SET sold=1 WHERE id=?",new Object[]{id});toast("فروش ثبت شد.");show();}).show()));}box.addView(button("حذف",()->new AlertDialog.Builder(this).setMessage("این خودرو حذف شود؟").setNegativeButton("لغو",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("cars","id=?",new String[]{""+id});show();}).show()));body.addView(box);View gap=new View(this);body.addView(gap,new LinearLayout.LayoutParams(1,10));}c.close();}
    void customers(){body.addView(button("+ ثبت مشتری",()->customerForm()));Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,phone,note FROM customers ORDER BY id DESC",null);if(c.getCount()==0)body.addView(text("مشتری‌ای ثبت نشده است.",17,navy));while(c.moveToNext())body.addView(text(c.getString(1)+"\n"+c.getString(2)+"\n"+c.getString(3),17,navy));c.close();}
    void customerForm(){page="مشتریان";show();body.addView(text("ثبت مشتری جدید",22,navy));EditText n=edit("نام و نام خانوادگی");EditText p=edit("شماره تماس");EditText note=edit("توضیحات");body.addView(button("ذخیره مشتری",()->{if(n.length()==0){toast("نام مشتری را وارد کن.");return;}android.content.ContentValues v=new android.content.ContentValues();v.put("name",n.getText().toString());v.put("phone",p.getText().toString());v.put("note",note.getText().toString());db.getWritableDatabase().insert("customers",null,v);toast("مشتری ثبت شد.");show();}));}
    void debts(){body.addView(button("+ ثبت بدهی یا طلب",()->debtForm()));Cursor c=db.getReadableDatabase().rawQuery("SELECT name,amount,type,note FROM debts ORDER BY id DESC",null);if(c.getCount()==0)body.addView(text("حسابی ثبت نشده است.",17,navy));while(c.moveToNext())body.addView(text(c.getString(0)+" · "+c.getString(2)+"\n"+money(c.getLong(1))+"\n"+c.getString(3),17,navy));c.close();}
    void debtForm(){page="بدهی‌ها";show();body.addView(text("ثبت حساب",22,navy));EditText n=edit("نام شخص یا شرکت");EditText a=edit("مبلغ به ریال");EditText note=edit("شرح حساب");final String[] type={"طلب (دریافتنی)"};Spinner sp=new Spinner(this);String[] opts={"طلب (دریافتنی)","بدهی (پرداختنی)"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){type[0]=opts[pos];}});body.addView(sp);body.addView(button("ذخیره حساب",()->{if(n.length()==0||!number(a)){toast("نام و مبلغ معتبر را وارد کن.");return;}android.content.ContentValues v=new android.content.ContentValues();v.put("name",n.getText().toString());v.put("amount",Long.parseLong(a.getText().toString()));v.put("type",type[0]);v.put("note",note.getText().toString());db.getWritableDatabase().insert("debts",null,v);toast("حساب ثبت شد.");show();}));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    static class ContentValuesCompat {static void insertCar(DB db,String b,String m,String y,long buy,long sell,String note,String photo){android.content.ContentValues v=new android.content.ContentValues();v.put("brand",b);v.put("model",m);v.put("year",y);v.put("buy",buy);v.put("sell",sell);v.put("note",note);v.put("photo",photo);v.put("sold",0);db.getWritableDatabase().insert("cars",null,v);}}
    static class DB extends SQLiteOpenHelper {DB(Context c){super(c,"autogallery.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE cars(id INTEGER PRIMARY KEY AUTOINCREMENT,brand TEXT,model TEXT,year TEXT,buy INTEGER,sell INTEGER,note TEXT,photo TEXT,sold INTEGER DEFAULT 0)");d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,note TEXT)");d.execSQL("CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,amount INTEGER,type TEXT,note TEXT)");}public void onUpgrade(SQLiteDatabase d,int o,int n){}}
}
